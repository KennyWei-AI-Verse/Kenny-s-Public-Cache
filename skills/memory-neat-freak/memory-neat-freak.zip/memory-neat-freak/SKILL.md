---
name: memory-neat-freak
description: A focused cleanup skill for agent memory, rules, deliverables, and context hygiene. Use when the user mentions memory cleanup, too many rules, stale context, conflicting instructions, context slimming, end-of-phase cleanup, handoff preparation, artifact cleanup, or wants to critically adapt an external skill/methodology.
version: 1.0.2
---

# Memory Neat Freak — Agent Memory, Rule & Deliverable Cleanup

## Purpose

You are a **knowledge editor**, not a recorder.

Your job is to keep an agent's long-term memory, behavior rules, collaboration notes, and related deliverables clean, accurate, lightweight, and safe.

Core principle:

> Be specific, be critical, and only keep information that will change future behavior.

This skill helps prevent long-running agents from becoming overloaded by stale notes, duplicated rules, conflicting instructions, outdated deliverables, and sensitive information.

## When to Use

Use this skill when the user mentions:

- memory cleanup
- too many rules
- stale context
- messy memory
- context slimming
- clean up docs / clean up memory
- sync up
- end-of-phase cleanup
- handoff preparation
- conflicting rules
- outdated project notes
- sensitive information in memory
- artifact cleanup after a deliverable task
- critically adapting an external skill or methodology

Examples:

```text
/neat
clean up memory
整理记忆
规则太多了
上下文太乱了
同步一下
收尾整理
批判吸收这个 skill
clean up the deck after this task
```

## Default Scope

By default, only inspect and edit directly relevant agent memory, rule files, and task deliverables, such as:

- long-term memory files
- daily notes
- agent behavior rules
- user preference files
- heartbeat / task-state notes
- project handoff notes, if directly relevant
- source files and exported artifacts created by the current task, if cleanup follows a deliverable task

Do **not** expand into unrelated project code or full repository documentation unless the user explicitly asks.

## Forbidden Scope

Do not touch by default:

- credential directories
- `.ssh/`, `.aws/`, `.config/`
- browser cookies or sessions
- token / secret / key files
- production data
- unrelated project source code
- external publishing actions
- public posts, emails, or messages

If you find sensitive information, do not copy or repeat the value. Only report the location and recommend redaction or rotation.

## Workflow

### 1. Inventory First

Before editing, inspect the relevant memory/rule files and identify four types of problems:

1. **Duplicates** — the same rule or preference appears in multiple places.
2. **Conflicts** — two or more rules point in different directions.
3. **Stale Information** — completed tasks, outdated project phases, old incidents, or temporary decisions remain in long-term memory.
4. **Overweight Rules** — rules are too detailed, too broad, or too costly to follow in daily work.

Do not expand the scan endlessly. Stay within the user’s actual cleanup intent.

### 2. Classify Each Candidate

For each piece of information, classify it as one of the following:

- **Keep** — stable, long-term, and likely to affect future decisions.
- **Merge** — duplicate information that should be compressed into one clear rule.
- **Downgrade** — move from global memory into daily notes, project memory, runbook, or handoff notes.
- **Delete** — outdated, wrong, one-off, or no longer useful.
- **Needs Confirmation** — anything involving user preference changes, risk boundaries, public actions, project direction, or deletion of important long-term memory.

### 3. Use Dry-run Before Major Edits

If the cleanup affects more than a few items, or rewrites core memory/rule files, first produce a dry-run summary.

```text
Suggested cleanup:
- Keep:
- Merge:
- Downgrade:
- Delete:
- Needs confirmation:

Please reply OK before I apply these changes.
```

Do not perform large edits before the user confirms.

Small, low-risk cleanups may be done directly, but still summarize the result.


## Associated Skill Updates

When `/neat` is triggered after reviewing a task, do not only inspect memory and deliverables. Also ask whether the task exposed a gap in another existing skill.

Rules:

- If updating an existing skill would prevent the same failure from recurring, include that skill as a candidate for update.
- If it is clear which skill should change and the change is a low-risk textual rule addition, it may be included in the cleanup.
- If it is unclear which skill is involved, whether it should be changed, or how it should be changed, list it under “Needs confirmation” instead of editing directly.
- Do not scan or rewrite all skills just because `/neat` was triggered. Only handle skills directly related to the task being reviewed.
- If a skill is updated, keep the local enabled version, repository version, and public/submission package synchronized when applicable.

Examples:

- A deck task exposes repeated diagrams or mismatched exports → update the relevant presentation/deck workflow skill or deliverable cleanup rules.
- A publishing task exposes a review gap → update the relevant publishing/sharing skill.
- A coding task exposes a recurring testing gate issue → update the relevant engineering/test skill.

## Deliverable Cleanup: PPT / Deck / Docs / Packages

When `/neat` is triggered after a deliverable task, do not only clean memory. Also check whether the task’s **source files, generation scripts, exported artifacts, and handoff notes** are synchronized.

This applies to:

- slide decks
- HTML presentations
- PDFs
- long images
- sharing posts
- skill packages
- handoff documents

Checklist:

- **Source first**: modify the source script or source document, not only the exported artifact.
- **Artifact sync**: HTML, PDF, zip, screenshots, and links should all come from the same version.
- **Visual information gain**: diagrams should not simply repeat bullet text; they should express relationships, tension, process, boundaries, or decision frameworks.
- **Avoid repeated visuals**: do not reuse the same diagram across many pages unless it directly serves each page.
- **Detail check**: inspect page numbers, dates, title spacing, overflow, typos, and sensitive/internal information.
- **Evidence**: run at least one concrete verification step such as open/screenshot/export/grep/structure check.

If source and exported artifacts are out of sync, fix the sync first. If the change is large, produce a dry-run before applying it.

## Editing Principles

- Less is better.
- Merge instead of appending.
- Delete outdated context instead of preserving everything.
- Long-term memory should only contain long-term facts.
- Temporary progress belongs in daily notes.
- Project-specific details belong in project memory or runbooks.
- Rules should describe behavior, not emotions or apologies.
- Use absolute dates, not “today”, “yesterday”, or “recently”.
- Prefer scripts/checks over prompt-only rules when possible.
- Do not automate preference changes or risk-boundary changes without user confirmation.

## Rule Conflict Priority

When rules conflict, resolve them in this order:

1. Safety and compliance boundaries
2. The user’s latest explicit instruction
3. Deterministic scripts, validators, and operational gates
4. Long-term collaboration preferences
5. One-off task habits
6. Simpler stable rules over complex exception lists

If the conflict still cannot be resolved, ask the user one concise question.

## Sensitive Information Policy

Never preserve raw secrets in memory.

Do not store:

- API keys
- access tokens
- app secrets
- signing secrets
- passwords
- SSH credentials
- cookies
- browser sessions
- private production URLs, unless explicitly required and safe

Preferred pattern:

```text
Credential: stored in controlled local secret file
Purpose: used for X
Rotation: recommended if previously exposed
```

Do not write the actual value.

If a credential has already appeared in chat, memory, logs, or Git history, recommend rotation.

## Output Format After Cleanup

After completing cleanup, respond briefly:

```text
Cleanup completed.
- Merged:
- Downgraded / deleted:
- Kept:
- Needs confirmation:
- Safety notes:
```

Only list actual changes. Do not write a long reflection.

## When to Stay Conservative

Do not force cleanup when:

- The user is handling urgent work.
- The current task is simple Q&A.
- Cleanup would interrupt the main workflow.
- There is not enough evidence to judge whether a rule is outdated.
- The content may be important but ambiguous.

In those cases, record a small TODO or ask one clarifying question.

## Core Checklist

Before finishing, check:

- Are duplicated rules merged?
- Are conflicting rules resolved or flagged?
- Are outdated tasks removed or downgraded?
- Are project-specific details kept out of global memory?
- Are deliverable source files and exported artifacts synchronized?
- Do diagrams add structure instead of repeating text?
- Are secrets redacted?
- Are long-term rules short and actionable?
- Would a new agent become clearer or more confused after reading this?

The goal is not to make memory “complete”.

The goal is to make memory **useful, safe, and maintainable**.
