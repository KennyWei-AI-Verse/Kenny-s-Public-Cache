---
name: memory-neat-freak
description: A focused cleanup skill for agent memory, rules, and context hygiene. Use when the user mentions memory cleanup, too many rules, stale context, conflicting instructions, context slimming, end-of-phase cleanup, handoff preparation, or wants to critically adapt an external skill/methodology. It only handles agent memory, rules, and collaboration notes by default, not broad project-wide refactoring.
version: 1.0.0
---

# Memory Neat Freak — Agent Memory & Rule Cleanup

## Purpose

You are a **knowledge editor**, not a recorder.

Your job is to keep an agent's long-term memory, behavior rules, and collaboration notes clean, accurate, lightweight, and safe.

Core principle:

> Be specific, be critical, and only keep information that will change future behavior.

This skill helps prevent long-running agents from becoming overloaded by stale notes, duplicated rules, conflicting instructions, and sensitive information.

## When to Use

Use this skill when the user mentions:

- memory cleanup
- too many rules
- stale context
- messy memory
- context slimming
- clean up docs / clean up memory
- sync up
- end-of-phase cleanup
- handoff preparation
- conflicting rules
- outdated project notes
- sensitive information in memory
- critically adapting an external skill or methodology

Examples:

```text
/neat
clean up memory
整理记忆
规则太多了
上下文太乱了
同步一下
收尾整理
批判吸收这个 skill
```

## Default Scope

By default, only inspect and edit agent memory and rule files, such as:

- long-term memory files
- daily notes
- agent behavior rules
- user preference files
- heartbeat / task-state notes
- project handoff notes, if directly relevant

Do **not** expand into unrelated project code or full repository documentation unless the user explicitly asks.

## Forbidden Scope

Do not touch by default:

- credential directories
- `.ssh/`, `.aws/`, `.config/`
- browser cookies or sessions
- token / secret / key files
- production data
- unrelated project source code
- external publishing actions
- public posts, emails, or messages

If you find sensitive information, do not copy or repeat the value. Only report the location and recommend redaction or rotation.

## Workflow

### 1. Inventory First

Before editing, inspect the relevant memory/rule files and identify four types of problems:

1. **Duplicates**  
   The same rule or preference appears in multiple places.

2. **Conflicts**  
   Two or more rules point in different directions.

   Example:
   - “Always ask before acting”
   - “Act first, do not ask too much”

3. **Stale Information**  
   Completed tasks, outdated project phases, old incidents, or temporary decisions remain in long-term memory.

4. **Overweight Rules**  
   Rules are too detailed, too broad, or too costly to follow in daily work.

Do not expand the scan endlessly. Stay within the user’s actual cleanup intent.

### 2. Classify Each Candidate

For each piece of information, classify it as one of the following:

- **Keep**  
  Stable, long-term, and likely to affect future decisions.

- **Merge**  
  Duplicate information that should be compressed into one clear rule.

- **Downgrade**  
  Move from global memory into daily notes, project memory, runbook, or handoff notes.

- **Delete**  
  Outdated, wrong, one-off, or no longer useful.

- **Needs Confirmation**  
  Anything involving user preference changes, risk boundaries, public actions, project direction, or deletion of important long-term memory.

### 3. Use Dry-run Before Major Edits

If the cleanup affects more than a few items, or rewrites core memory/rule files, first produce a dry-run summary.

Use this format:

```text
Suggested cleanup:
- Keep:
- Merge:
- Downgrade:
- Delete:
- Needs confirmation:

Please reply OK before I apply these changes.
```

Do not perform large edits before the user confirms.

Small, low-risk cleanups may be done directly, but still summarize the result.

### 4. Editing Principles

- Less is better.
- Merge instead of appending.
- Delete outdated context instead of preserving everything.
- Long-term memory should only contain long-term facts.
- Temporary progress belongs in daily notes.
- Project-specific details belong in project memory or runbooks.
- Rules should describe behavior, not emotions or apologies.
- Use absolute dates, not “today”, “yesterday”, or “recently”.
- Prefer scripts/checks over prompt-only rules when possible.
- Do not automate preference changes or risk-boundary changes without user confirmation.

## Rule Conflict Priority

When rules conflict, resolve them in this order:

1. Safety and compliance boundaries
2. The user’s latest explicit instruction
3. Deterministic scripts, validators, and operational gates
4. Long-term collaboration preferences
5. One-off task habits
6. Simpler stable rules over complex exception lists

If the conflict still cannot be resolved, ask the user one concise question.

## Sensitive Information Policy

Never preserve raw secrets in memory.

Do not store:

- API keys
- access tokens
- app secrets
- signing secrets
- passwords
- SSH credentials
- cookies
- browser sessions
- private production URLs, unless explicitly required and safe

Preferred pattern:

```text
Credential: stored in controlled local secret file
Purpose: used for X
Rotation: recommended if previously exposed
```

Do not write the actual value.

If a credential has already appeared in chat, memory, logs, or Git history, recommend rotation.

## Output Format After Cleanup

After completing cleanup, respond briefly:

```text
Cleanup completed.
- Merged:
- Downgraded / deleted:
- Kept:
- Needs confirmation:
- Safety notes:
```

Only list actual changes. Do not write a long reflection.

## When to Stay Conservative

Do not force cleanup when:

- The user is handling urgent work.
- The current task is simple Q&A.
- Cleanup would interrupt the main workflow.
- There is not enough evidence to judge whether a rule is outdated.
- The content may be important but ambiguous.

In those cases, record a small TODO or ask one clarifying question.

## Recommended Use Cases

This skill is useful for:

- Long-running personal agents
- Project agents with persistent memory
- Multi-agent collaboration projects
- End-of-sprint cleanup
- Postmortem-to-memory conversion
- Handoff preparation
- Reducing prompt/rule bloat
- Removing stale project details from global memory
- Auditing whether sensitive data entered memory

## Anti-patterns

Avoid these behaviors:

- Appending yet another rule without removing old ones
- Treating memory cleanup as a full repository refactor
- Moving all details into global memory
- Deleting important context without confirmation
- Repeating or exposing secrets during cleanup
- Turning every preference into a rigid rule
- Copying an external skill without adapting its scope

## Core Checklist

Before finishing, check:

- Are duplicated rules merged?
- Are conflicting rules resolved or flagged?
- Are outdated tasks removed or downgraded?
- Are project-specific details kept out of global memory?
- Are secrets redacted?
- Are long-term rules short and actionable?
- Would a new agent become clearer or more confused after reading this?

The goal is not to make memory “complete”.

The goal is to make memory **useful, safe, and maintainable**.
